package service

// Result interface for output
type Result interface {
	Message() string
}
