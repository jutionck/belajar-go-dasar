package service

type NumberResult interface {
	PairsNumber() int
}
